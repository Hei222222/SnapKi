"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/scan-receipt.ts
var scan_receipt_exports = {};
__export(scan_receipt_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(scan_receipt_exports);
var allowedOrigins = /* @__PURE__ */ new Set([
  "https://snapkihk.netlify.app",
  "http://localhost:8081",
  "http://localhost:19006"
]);
var receiptPrompt = `
\u4F60\u662F Snap\u8A18\u7684\u6536\u64DA\u8207\u4ED8\u6B3E\u622A\u5716\u8FA8\u8B58\u52A9\u624B\u3002

\u8ACB\u53EA\u8FA8\u8B58\u4E00\u7B46\u5DF2\u5B8C\u6210\u4ED8\u6B3E\uFF0C\u4E26\u4E14\u53EA\u56DE\u50B3\u6709\u6548 JSON\uFF0C\u4E0D\u8981 Markdown \u6216\u89E3\u91CB\u3002

\u683C\u5F0F\uFF1A
{
  "merchant": "",
  "amount": 0,
  "date": "",
  "paymentMethod": "\u5176\u4ED6",
  "category": "\u5176\u4ED6",
  "confidence": 0
}

\u898F\u5247\uFF1A
- amount \u662F\u5BE6\u969B\u4ED8\u6B3E\u7E3D\u984D\uFF0C\u53EA\u586B\u6578\u5B57\u3002
- date \u4F7F\u7528 YYYY-MM-DD\uFF1B\u4E0D\u78BA\u5B9A\u5C31\u7559\u7A7A\u5B57\u4E32\u3002
- paymentMethod \u53EA\u53EF\u70BA Apple Pay\u3001AlipayHK\u3001WeChat Pay HK\u3001FPS\u3001\u73FE\u91D1\u3001\u5176\u4ED6\u3002
- category \u53EA\u53EF\u70BA \u4EA4\u901A\u3001\u98F2\u98DF\u3001\u8CFC\u7269\u3001\u5A1B\u6A02\u3001\u91AB\u7642\u3001\u4F4F\u5C4B\u3001\u5176\u4ED6\u3002
- confidence \u5FC5\u9808\u662F 0 \u81F3 1\u3002
`;
function response(statusCode, body, origin = "") {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": origin,
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "POST, OPTIONS"
    },
    body: JSON.stringify(body)
  };
}
function parseAiJson(text) {
  const clean = String(text || "").trim().replace(/^```json\s*/i, "").replace(/^```\s*/i, "").replace(/\s*```$/i, "").trim();
  const start = clean.indexOf("{");
  const end = clean.lastIndexOf("}");
  if (start < 0 || end < start) {
    throw new Error("AI \u6C92\u6709\u56DE\u50B3\u53EF\u8B80\u53D6\u7684 JSON\u3002");
  }
  return JSON.parse(clean.slice(start, end + 1));
}
function normalizeDraft(value) {
  const paymentMethods = /* @__PURE__ */ new Set([
    "Apple Pay",
    "AlipayHK",
    "WeChat Pay HK",
    "FPS",
    "\u73FE\u91D1",
    "\u5176\u4ED6"
  ]);
  const categories = /* @__PURE__ */ new Set([
    "\u4EA4\u901A",
    "\u98F2\u98DF",
    "\u8CFC\u7269",
    "\u5A1B\u6A02",
    "\u91AB\u7642",
    "\u4F4F\u5C4B",
    "\u5176\u4ED6"
  ]);
  const raw = value;
  const amount = Number(raw?.amount);
  return {
    merchant: typeof raw?.merchant === "string" ? raw.merchant.trim().slice(0, 120) : "",
    amount: Number.isFinite(amount) && amount > 0 ? Math.round(amount * 100) / 100 : 0,
    date: typeof raw?.date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(raw.date) ? raw.date : "",
    paymentMethod: typeof raw?.paymentMethod === "string" && paymentMethods.has(raw.paymentMethod) ? raw.paymentMethod : "\u5176\u4ED6",
    category: typeof raw?.category === "string" && categories.has(raw.category) ? raw.category : "\u5176\u4ED6",
    confidence: Math.max(0, Math.min(1, Number(raw?.confidence) || 0))
  };
}
async function handler(event, _context) {
  const origin = event.headers.origin || "";
  if (event.httpMethod === "OPTIONS") {
    return response(204, {}, origin);
  }
  if (event.httpMethod !== "POST") {
    return response(405, { error: "\u53EA\u652F\u63F4 POST\u3002" }, origin);
  }
  if (!allowedOrigins.has(origin)) {
    return response(403, { error: "\u4E0D\u5141\u8A31\u7684\u4F86\u6E90\u3002" }, origin);
  }
  const endpoint = String(process.env.AZURE_OPENAI_ENDPOINT || "").replace(/\/+$/, "");
  const apiKey = process.env.AZURE_OPENAI_API_KEY;
  const deployment = process.env.AZURE_OPENAI_DEPLOYMENT;
  if (!endpoint || !apiKey || !deployment) {
    return response(500, { error: "\u4F3A\u670D\u5668\u5C1A\u672A\u5B8C\u6210 Azure \u8A2D\u5B9A\u3002" }, origin);
  }
  let input;
  try {
    input = JSON.parse(event.body || "{}");
  } catch {
    return response(400, { error: "\u8ACB\u6C42\u683C\u5F0F\u4E0D\u6B63\u78BA\u3002" }, origin);
  }
  const imageDataUrl = input.imageDataUrl;
  if (typeof imageDataUrl !== "string" || !/^data:image\/(jpeg|jpg|png|webp);base64,/i.test(imageDataUrl)) {
    return response(400, { error: "\u8ACB\u63D0\u4F9B JPG\u3001PNG \u6216 WEBP \u5716\u7247\u3002" }, origin);
  }
  if (imageDataUrl.length > 7e6) {
    return response(413, { error: "\u5716\u7247\u592A\u5927\uFF0C\u8ACB\u4F7F\u7528\u5C0F\u65BC\u7D04 5 MB \u7684\u5716\u7247\u3002" }, origin);
  }
  try {
    const azureResponse = await fetch(
      `${endpoint}/openai/v1/chat/completions`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: deployment,
          messages: [
            {
              role: "system",
              content: "\u4F60\u53EA\u6703\u56DE\u50B3\u6709\u6548 JSON\u3002"
            },
            {
              role: "user",
              content: [
                {
                  type: "text",
                  text: receiptPrompt
                },
                {
                  type: "image_url",
                  image_url: {
                    url: imageDataUrl,
                    detail: "low"
                  }
                }
              ]
            }
          ],
          temperature: 0,
          max_completion_tokens: 300,
          response_format: {
            type: "json_object"
          }
        })
      }
    );
    if (!azureResponse.ok) {
      const errorText = await azureResponse.text().catch(() => "");
      console.error("Azure OpenAI \u932F\u8AA4\u72C0\u614B\uFF1A", azureResponse.status, errorText);
      return response(500, { error: "\u672A\u80FD\u5B8C\u6210\u6536\u64DA\u8FA8\u8B58\u3002" }, origin);
    }
    const azureResult = await azureResponse.json();
    const aiText = azureResult?.choices?.[0]?.message?.content ?? "";
    if (typeof aiText !== "string" || !aiText.trim()) {
      console.error("AI \u56DE\u50B3\u5167\u5BB9\u70BA\u7A7A\u6216\u683C\u5F0F\u932F\u8AA4\uFF1A", azureResult);
      return response(500, { error: "\u672A\u80FD\u5B8C\u6210\u6536\u64DA\u8FA8\u8B58\u3002" }, origin);
    }
    const draft = normalizeDraft(parseAiJson(aiText));
    return response(200, { draft }, origin);
  } catch (error) {
    console.error(
      "Receipt scan error:",
      error instanceof Error ? error.message : String(error)
    );
    return response(500, { error: "\u672A\u80FD\u5B8C\u6210\u6536\u64DA\u8FA8\u8B58\u3002" }, origin);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
